import React from "react";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
} from "reactstrap";

import api from '../services/api';

class Tables extends React.Component {

  state = {
    _caixas: [],
    _produtos: []
  }

  async componentDidMount() {
    const response = await api.get('/caixas');  
    this.setState({ _caixas : response.data });


    const res = await api.get('/produtos');
    this.setState({ _produtos : res.data});
  }

  render() {
    return (
      <>
        <div className="content">
          <Row>
            <Col md="12">
              <Card className="card-plain">
                <CardHeader>
                  <CardTitle tag="h4">Table on Plain Background</CardTitle>
                  <p className="card-category">
                    Here is a subtitle for this table
                  </p>
                </CardHeader>
                <CardBody>
                  <Table responsive>
                    <thead className="text-primary">
                      <tr>
                        <th>id</th>
                        <th>dataabertura</th>
                        <th>datafechamento</th>
                        <th>status</th>
                        <th>valorabertura</th>
                        <th>valorfechamento</th>
                        <th>fiscalAbertura</th>
                        <th>fiscalFechamento</th>
                        <th>operador</th>
                        <th>dataalteracao</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state._caixas.map(caixa => (
                        <tr key={caixa.id}>
                        <td>{caixa.id}</td>
                        <td>{caixa.dataabertura}</td>
                        <td>{caixa.datafechamento}</td>
                        <td>{caixa.status}</td>
                        <td>{caixa.valorabertura}</td>
                        <td>{caixa.valorfechamento}</td>
                        <td>{caixa.fiscalAbertura}</td>
                        <td>{caixa.fiscalFechamento}</td>
                        <td>{caixa.operador}</td>
                        <td>{caixa.dataalteracao}</td>
                      </tr>  
                      ))}
                    </tbody>
                  </Table>
                </CardBody>
              </Card>
            </Col>




            <Col md="12">
              <Card className="card-plain">
                <CardHeader>
                  <CardTitle tag="h4">Table on Plain Background</CardTitle>
                  <p className="card-category">
                    Here is a subtitle for this table
                  </p>
                </CardHeader>
                <CardBody>
                  <Table responsive>
                    <thead className="text-primary">
                      <tr>
                        <th>id</th>
                        <th>codigo</th>
                        <th>descricao</th>
                        <th>preco</th>
                        <th>ncm</th>
                        <th>aliquota</th>
                        <th>st</th>
                        <th>status</th>
                        <th>dataalteracao</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state._produtos.map(produto => (
                        <tr key={produto.id}>
                        <td>{produto.id}</td>
                        <td>{produto.codigo}</td>
                        <td>{produto.descricao}</td>
                        <td>{produto.preco}</td>
                        <td>{produto.ncm}</td>
                        <td>{produto.aliquota}</td>
                        <td>{produto.st}</td>
                        <td>{produto.status}</td>
                        <td>{produto.dataalteracao}</td>
                      </tr>  
                      ))}
                    </tbody>
                  </Table>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </>
    );
  }
}

export default Tables;
